#include<stdio.h>
int factorial(int *p){
    int prod=1;
    for(int i=1;i<=*p;i++){
        prod=prod*i;
    }
    return prod;
}
int main(){
    int a,b;
    scanf("%d",&a);
   b=factorial(&a);
    printf("the factorial of %d is %d",a,b);
    return 0;
}