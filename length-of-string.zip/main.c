#include<stdio.h>
int main(){
    int i,j;
    char str[10],temp;
    fgets(str,10,stdin);
    for(i=0;str[i];i++);
    for(j=0;j<i/2;j++){
        temp=str[i-j-1];
        str[i-j-1]=str[j];
        str[j]=temp;
    }
    printf("%s",str);
    return 0;
}