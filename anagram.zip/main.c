#include<stdio.h>
#include<string.h>
int main(){
    char str1[8]="himanshu",str2[8]="rrrrrrrr";
    int a,b,i,j,count=0;
    a=strlen(str1);
    b=strlen(str2);
    if(a==b){
        for(int i=0;str1[i];i++){
            if(str1[i]==str2[i])
            count++;
        }
        if(count==a)
        printf("good");
        else
        printf("not");
    }
    else
    printf("sahi");
    return 0;
}