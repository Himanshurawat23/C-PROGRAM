#include<stdio.h>
#include<math.h>
GP()
int main(){
   int a,r,n;
   printf("enter the first term: ");
   scanf("%d",&a);
   printf("enter the common ratio: ");
   scanf("%d",&r);
   printf("emter the number of terms: ");
   scanf("%d",&n);
   GP(&a,&r,&n);
   return 0;
}
   
   