#include<stdio.h>
#include<string.h>
int main(){
    char str[]="himanshu",p[]="rawat",str_1[100];
    int a,b,i,j;
    a=strlen(str),b=strlen(p);
    for( i=0;i<a+b;i++){
        str_1[i]=str[i];
        if(i==a){
            for(j=0;j<b;j++){
            str_1[i]=p[j];
            i++;
        }
    }
    if(i<=a+b)
        break;
}
printf("%s",str_1);
return 0;
}