#include<stdio.h>
int call(int *p,int *q){
    int c;
    c=*p + *q;
    return c;
}
void PointerArray(int *p,int n){
    for(int i=0;i<n;i++){
        scanf("%d",p+i);
    }
}
 void printArr(int *p,int n){
    for(int i=0;i<n;i++)
    printf("%d",*(p+i));
}
int main(){
/*    int a,b,sum;
    scanf("%d %d",&a,&b);
    sum=call(&a,&b);
    printf("the sum of %d and %d is %d ",a,b,sum);*/
    int n,*q;
 scanf("%d",&n);
    int arr[n];
    PointerArray(arr,n);
    printArr(arr,n);
    return 0;
}
