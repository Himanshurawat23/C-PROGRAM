#include<stdio.h>
void SimpleInterest(int *a,int *b,int *c){
    int s=*a+*b+*c;
    printf(" the SIMPLE INTERSERT IS %d",s);
}
void swap(int *p,int *q){
    int temp=*p;
    *p=*q;
    *q=temp;
}
int maximum(int *p,int *q,int *r){
    if(*p>*q && *p>*r){
        printf("%d is maximum",*p);
        return 1;
    }
    else if(*q>*r){
    printf("%d is maximum",*q);
    return 1;
    }
    else
    printf("%d is maximum",*r);
    
}
int main(){
    /*int p,q,r;
    scanf("%d %d %d",&p,&q,&r);
    SimpleInterest(&p,&q,&r);*/
    int a,b,c;
    scanf("%d %d %d",&a,&b,&c);
//    swap(&a,&b);
  //  printf("after swapping is a=%d and b=%d",a,b);
  maximum(&a,&b,&c);
    return 0;
}