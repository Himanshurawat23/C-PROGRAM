#include<stdio.h>
int main(){
    char str[10]="PROGRAM";
    for(int i=0;str[i];i++){
        for(int j=0;j<=i;j++)
        printf("%c",str[j]);
        printf("\n");
    }
    return 0;
}